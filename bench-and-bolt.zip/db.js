const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'shop.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id          INTEGER PRIMARY KEY,
  name        TEXT NOT NULL,
  category    TEXT NOT NULL,
  description TEXT NOT NULL,
  price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
  stock       INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  color       TEXT NOT NULL DEFAULT '#14213D'
);

CREATE TABLE IF NOT EXISTS orders (
  id           INTEGER PRIMARY KEY,
  user_id      INTEGER NOT NULL REFERENCES users(id),
  total_cents  INTEGER NOT NULL,
  status       TEXT NOT NULL DEFAULT 'placed',
  ship_name    TEXT NOT NULL,
  ship_address TEXT NOT NULL,
  ship_city    TEXT NOT NULL,
  ship_postal  TEXT NOT NULL,
  created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
  id               INTEGER PRIMARY KEY,
  order_id         INTEGER NOT NULL REFERENCES orders(id),
  product_id       INTEGER NOT NULL REFERENCES products(id),
  product_name     TEXT NOT NULL,
  unit_price_cents INTEGER NOT NULL,
  quantity         INTEGER NOT NULL CHECK (quantity > 0)
);
`);

// Seed demo products on first run
if (db.prepare('SELECT COUNT(*) AS n FROM products').get().n === 0) {
  const insert = db.prepare(
    'INSERT INTO products (name, category, description, price_cents, stock, color) VALUES (?, ?, ?, ?, ?, ?)'
  );
  const seed = [
    ['Cross-Cut Backsaw, 12 in', 'Saws', 'Fine 14 TPI teeth for dovetails and tenons. Brass spine keeps the cut straight, beech handle fits a full grip.', 4800, 14, '#2F4B6E'],
    ['Cast Iron Block Plane', 'Planes', 'Low-angle block plane with a hardened A2 blade. Trims end grain and softens edges without tear-out.', 7900, 8, '#5C6B7A'],
    ['Combination Square, 300 mm', 'Measuring', 'Hardened steel rule with etched graduations and a cast head. Checks 90° and 45° and doubles as a depth gauge.', 3400, 25, '#E8590C'],
    ['Bench Chisel Set, 4 pc', 'Chisels', 'Four chisels (6, 12, 19, 25 mm) in chrome-vanadium steel, with hornbeam handles and a leather roll.', 6400, 11, '#1D3557'],
    ['Pull-Out Marking Gauge', 'Measuring', 'Wheel-cutter marking gauge that scribes clean lines across the grain. Brass thumbscrew locks the fence.', 2600, 30, '#8A5A2B'],
    ['Waxed Canvas Shop Apron', 'Apparel', 'Heavy 16 oz canvas, cross-back straps, and a chest pocket that holds a pencil and a tape.', 5200, 18, '#3E5C4A'],
    ['Diamond Sharpening Plate', 'Sharpening', 'Double-sided 400/1000 grit plate that stays flat. Use it dry or with water, and no soaking is needed.', 3900, 0, '#4A4E69'],
    ['Pencil & Awl Set', 'Marking', 'Three carpenter pencils, two refills of lead, and a pocket awl for starting screws accurately.', 1400, 60, '#B3541E'],
  ];
  const tx = db.transaction(rows => rows.forEach(r => insert.run(...r)));
  tx(seed);
}

module.exports = db;
