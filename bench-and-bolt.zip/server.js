const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'dev-only-secret-change-me',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'lax', maxAge: 7 * 24 * 60 * 60 * 1000 },
  })
);
app.use(express.static(path.join(__dirname, 'public')));

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const requireAuth = (req, res, next) =>
  req.session.userId ? next() : res.status(401).json({ error: 'Sign in to continue.' });

/* ---------- Products ---------- */

app.get('/api/products', (req, res) => {
  const q = String(req.query.q || '').trim();
  const category = String(req.query.category || '').trim();
  let sql = 'SELECT * FROM products WHERE 1=1';
  const params = [];
  if (q) {
    sql += ' AND (name LIKE ? OR description LIKE ?)';
    params.push(`%${q}%`, `%${q}%`);
  }
  if (category) {
    sql += ' AND category = ?';
    params.push(category);
  }
  sql += ' ORDER BY id';
  res.json(db.prepare(sql).all(...params));
});

app.get('/api/categories', (req, res) => {
  res.json(db.prepare('SELECT DISTINCT category FROM products ORDER BY category').all().map(r => r.category));
});

app.get('/api/products/:id', (req, res) => {
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'Product not found.' });
  res.json(p);
});

/* ---------- Auth ---------- */

const publicUser = u => ({ id: u.id, name: u.name, email: u.email });

app.post('/api/register', (req, res) => {
  const name = String(req.body?.name || '').trim();
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');

  if (!name) return res.status(400).json({ error: 'Enter your name.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 8) return res.status(400).json({ error: 'Use a password with at least 8 characters.' });
  if (db.prepare('SELECT id FROM users WHERE email = ?').get(email))
    return res.status(409).json({ error: 'An account with that email already exists. Try signing in.' });

  const hash = bcrypt.hashSync(password, 10);
  const id = db
    .prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)')
    .run(name, email, hash).lastInsertRowid;

  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Something went wrong.' });
    req.session.userId = Number(id);
    res.status(201).json({ id: Number(id), name, email });
  });
});

app.post('/api/login', (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash))
    return res.status(401).json({ error: 'Email or password is incorrect.' });

  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Something went wrong.' });
    req.session.userId = user.id;
    res.json(publicUser(user));
  });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/me', (req, res) => {
  if (!req.session.userId) return res.json(null);
  const user = db.prepare('SELECT id, name, email FROM users WHERE id = ?').get(req.session.userId);
  res.json(user || null);
});

/* ---------- Orders ---------- */

const getProduct = db.prepare('SELECT * FROM products WHERE id = ?');
const insertOrder = db.prepare(
  `INSERT INTO orders (user_id, total_cents, ship_name, ship_address, ship_city, ship_postal)
   VALUES (?, ?, ?, ?, ?, ?)`
);
const insertItem = db.prepare(
  `INSERT INTO order_items (order_id, product_id, product_name, unit_price_cents, quantity)
   VALUES (?, ?, ?, ?, ?)`
);
const decrementStock = db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?');

app.post('/api/orders', requireAuth, (req, res) => {
  const { items, shipping } = req.body || {};
  if (!Array.isArray(items) || items.length === 0)
    return res.status(400).json({ error: 'Your cart is empty.' });

  const ship = {};
  for (const [key, label] of [['name', 'name'], ['address', 'address'], ['city', 'city'], ['postal', 'postal code']]) {
    const v = String(shipping?.[key] || '').trim();
    if (!v) return res.status(400).json({ error: `Enter a shipping ${label}.` });
    ship[key] = v.slice(0, 200);
  }

  // Merge duplicate lines
  const wanted = new Map();
  for (const it of items) {
    const id = Number(it.productId);
    const qty = Number(it.quantity);
    if (!Number.isInteger(id) || !Number.isInteger(qty) || qty < 1 || qty > 99)
      return res.status(400).json({ error: 'Cart contains an invalid item.' });
    wanted.set(id, (wanted.get(id) || 0) + qty);
  }

  // Prices and stock are always read from the database, never from the client.
  const place = db.transaction(() => {
    let total = 0;
    const lines = [];
    for (const [id, qty] of wanted) {
      const p = getProduct.get(id);
      if (!p) throw new HttpError(400, 'A product in your cart is no longer available.');
      if (p.stock < qty)
        throw new HttpError(409, p.stock === 0 ? `${p.name} is out of stock.` : `Only ${p.stock} of ${p.name} left.`);
      lines.push({ p, qty });
      total += p.price_cents * qty;
    }
    const orderId = insertOrder.run(req.session.userId, total, ship.name, ship.address, ship.city, ship.postal)
      .lastInsertRowid;
    for (const { p, qty } of lines) {
      insertItem.run(orderId, p.id, p.name, p.price_cents, qty);
      decrementStock.run(qty, p.id);
    }
    return Number(orderId);
  });

  try {
    res.status(201).json({ orderId: place() });
  } catch (e) {
    if (e instanceof HttpError) return res.status(e.status).json({ error: e.message });
    console.error(e);
    res.status(500).json({ error: 'Something went wrong placing your order.' });
  }
});

app.get('/api/orders', requireAuth, (req, res) => {
  const orders = db
    .prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC')
    .all(req.session.userId);
  const itemsStmt = db.prepare('SELECT * FROM order_items WHERE order_id = ?');
  res.json(orders.map(o => ({ ...o, items: itemsStmt.all(o.id) })));
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

app.listen(PORT, () => console.log(`Bench & Bolt running at http://localhost:${PORT}`));
