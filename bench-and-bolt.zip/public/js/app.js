/* Bench & Bolt storefront: one script, one render function per page */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = cents => '$' + (cents / 100).toFixed(2);
const app = $('#app');
const state = { user: null };

async function api(url, opts = {}) {
  const res = await fetch(url, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed.');
  return data;
}

/* ---- cart (localStorage; the server re-checks prices and stock at checkout) ---- */
const Cart = {
  get() {
    try {
      const c = JSON.parse(localStorage.getItem('cart') || '[]');
      return Array.isArray(c) ? c : [];
    } catch { return []; }
  },
  save(c) { localStorage.setItem('cart', JSON.stringify(c)); updateBadge(); },
  add(id, qty = 1) {
    const c = this.get();
    const line = c.find(i => i.id === id);
    line ? (line.qty = Math.min(99, line.qty + qty)) : c.push({ id, qty });
    this.save(c);
  },
  set(id, qty) {
    const c = this.get();
    this.save(qty < 1 ? c.filter(i => i.id !== id) : c.map(i => (i.id === id ? { ...i, qty: Math.min(99, qty) } : i)));
  },
  clear() { this.save([]); },
  count() { return this.get().reduce((n, i) => n + i.qty, 0); },
};

function updateBadge() {
  const b = $('#badge');
  if (b) b.textContent = Cart.count();
}

function renderHeader() {
  $('#site-header').innerHTML = `
    <div class="wrap bar">
      <a class="brand" href="/">Bench &amp; Bolt</a>
      <nav>
        ${state.user
          ? `<a href="/orders.html">Orders</a><button class="link" id="logout">Sign out</button>`
          : `<a href="/login.html">Sign in</a>`}
        <a href="/cart.html">Cart <span id="badge" class="badge">0</span></a>
      </nav>
    </div>`;
  updateBadge();
  const out = $('#logout');
  if (out) out.onclick = async () => { await api('/api/logout', { method: 'POST' }); location.href = '/'; };
}

const showMsg = (el, text, type = 'err') => { el.className = `msg ${type}`; el.textContent = text; el.hidden = false; };
const stockLabel = p =>
  p.stock === 0 ? '<span class="stock-out">Out of stock</span>'
  : p.stock <= 5 ? `<span class="stock-low">Only ${p.stock} left</span>`
  : '<span class="stock-ok">In stock</span>';
const tile = p => `<div class="tile" style="--tile:${esc(p.color)}">${esc(p.category)}</div>`;

const pages = {};

/* ---- product listing ---- */
pages.home = async () => {
  app.innerHTML = `
    <section class="hero">
      <h1>Tools that earn their bench space.</h1>
      <p>Hand tools and workshop supplies, shipped from one small warehouse.</p>
    </section>
    <div class="filters">
      <input id="q" type="search" placeholder="Search products" aria-label="Search products">
      <div id="cats" class="chips" role="group" aria-label="Categories"></div>
    </div>
    <div id="grid" class="grid" aria-live="polite"></div>`;

  let category = '';
  let timer;
  const load = async () => {
    const q = encodeURIComponent($('#q').value.trim());
    const list = await api(`/api/products?q=${q}&category=${encodeURIComponent(category)}`);
    $('#grid').innerHTML = list.length
      ? list.map(p => `
        <article class="card">
          <a class="media" href="/product.html?id=${p.id}" aria-label="${esc(p.name)}">${tile(p)}</a>
          <div class="body">
            <h3><a href="/product.html?id=${p.id}" style="text-decoration:none">${esc(p.name)}</a></h3>
            <div class="meta">${stockLabel(p)}</div>
            <div class="foot">
              <span class="price">${money(p.price_cents)}</span>
              <button class="btn sm" data-add="${p.id}" ${p.stock === 0 ? 'disabled' : ''}>Add to cart</button>
            </div>
          </div>
        </article>`).join('')
      : '<p class="empty">No products match. Try a different search or category.</p>';
  };

  const cats = await api('/api/categories');
  const renderChips = () => {
    $('#cats').innerHTML = ['All', ...cats].map(c =>
      `<button class="chip" aria-pressed="${(c === 'All' ? '' : c) === category}" data-cat="${esc(c)}">${esc(c)}</button>`).join('');
  };
  renderChips();
  $('#cats').onclick = e => {
    const b = e.target.closest('[data-cat]');
    if (!b) return;
    category = b.dataset.cat === 'All' ? '' : b.dataset.cat;
    renderChips();
    load();
  };
  $('#q').oninput = () => { clearTimeout(timer); timer = setTimeout(load, 250); };
  $('#grid').onclick = e => {
    const b = e.target.closest('[data-add]');
    if (!b) return;
    Cart.add(Number(b.dataset.add));
    b.textContent = 'Added';
    setTimeout(() => (b.textContent = 'Add to cart'), 1200);
  };
  load();
};

/* ---- product details ---- */
pages.product = async () => {
  const id = Number(new URLSearchParams(location.search).get('id'));
  let p;
  try { p = await api(`/api/products/${id}`); }
  catch { app.innerHTML = '<p class="empty">We couldn\'t find that product. <a href="/">Back to all products</a></p>'; return; }

  document.title = `${p.name} | Bench & Bolt`;
  app.innerHTML = `
    <a class="crumb" href="/">&larr; All products</a>
    <div class="detail">
      ${tile(p)}
      <div>
        <h1 style="font-size:2.2rem">${esc(p.name)}</h1>
        <p class="price">${money(p.price_cents)}</p>
        <p>${esc(p.description)}</p>
        <p>${stockLabel(p)}</p>
        <div class="buy">
          <div class="qty"><label for="qty">Quantity</label>
            <input id="qty" type="number" min="1" max="${Math.min(99, p.stock) || 1}" value="1" ${p.stock === 0 ? 'disabled' : ''}></div>
          <button class="btn" id="add" ${p.stock === 0 ? 'disabled' : ''}>Add to cart</button>
        </div>
        <p id="added" class="msg ok" hidden></p>
      </div>
    </div>`;
  $('#add').onclick = () => {
    const qty = Math.max(1, Math.min(Number($('#qty').value) || 1, p.stock));
    Cart.add(p.id, qty);
    showMsg($('#added'), `Added ${qty} to your cart.`, 'ok');
    $('#added').innerHTML += ' <a href="/cart.html">View cart</a>';
  };
};

/* ---- cart + checkout ---- */
pages.cart = async () => {
  const all = await api('/api/products');
  const byId = new Map(all.map(p => [p.id, p]));

  const draw = () => {
    const lines = Cart.get().filter(l => byId.has(l.id)).map(l => ({ ...l, p: byId.get(l.id) }));
    if (!lines.length) {
      app.innerHTML = '<h1>Your cart</h1><div class="panel empty">Your cart is empty. <a href="/">Browse products</a></div>';
      return;
    }
    const total = lines.reduce((s, l) => s + l.p.price_cents * l.qty, 0);
    app.innerHTML = `
      <h1>Your cart</h1>
      <div class="two">
        <div class="panel">
          ${lines.map(l => `
            <div class="cart-row">
              <div class="tile" style="--tile:${esc(l.p.color)}"></div>
              <div><a href="/product.html?id=${l.p.id}"><strong>${esc(l.p.name)}</strong></a><br><span class="meta">${money(l.p.price_cents)} each</span></div>
              <div class="stepper">
                <button data-dec="${l.id}" aria-label="Decrease quantity of ${esc(l.p.name)}">&minus;</button>
                <span>${l.qty}</span>
                <button data-inc="${l.id}" aria-label="Increase quantity of ${esc(l.p.name)}">+</button>
              </div>
              <div class="line-total"><strong>${money(l.p.price_cents * l.qty)}</strong>
                <button class="link" data-rm="${l.id}" style="margin-left:.75rem;color:var(--steel);text-decoration:underline">Remove</button></div>
            </div>`).join('')}
          <div class="totals"><span>Total</span><span>${money(total)}</span></div>
        </div>
        <div class="panel" id="checkout"></div>
      </div>`;

    $('.panel').onclick = e => {
      const t = e.target.closest('button');
      if (!t) return;
      const cur = id => Cart.get().find(l => l.id === id)?.qty || 0;
      if (t.dataset.inc) Cart.set(Number(t.dataset.inc), cur(Number(t.dataset.inc)) + 1);
      else if (t.dataset.dec) Cart.set(Number(t.dataset.dec), cur(Number(t.dataset.dec)) - 1);
      else if (t.dataset.rm) Cart.set(Number(t.dataset.rm), 0);
      else return;
      draw();
    };

    const box = $('#checkout');
    if (!state.user) {
      box.innerHTML = `<h2>Checkout</h2><p>Sign in or create an account to place your order.</p>
        <a class="btn" href="/login.html?next=/cart.html">Sign in to check out</a>`;
      return;
    }
    box.innerHTML = `
      <h2>Shipping</h2>
      <div id="err" class="msg err" hidden></div>
      <form id="ship" class="form-grid">
        <div><label for="n">Full name</label><input id="n" required autocomplete="name" value="${esc(state.user.name)}"></div>
        <div><label for="a">Street address</label><input id="a" required autocomplete="street-address"></div>
        <div><label for="c">City</label><input id="c" required autocomplete="address-level2"></div>
        <div><label for="z">Postal code</label><input id="z" required autocomplete="postal-code"></div>
        <button class="btn" type="submit">Place order &middot; ${money(total)}</button>
      </form>`;
    $('#ship').onsubmit = async e => {
      e.preventDefault();
      const btn = e.target.querySelector('button');
      btn.disabled = true;
      try {
        const { orderId } = await api('/api/orders', {
          method: 'POST',
          body: {
            items: lines.map(l => ({ productId: l.id, quantity: l.qty })),
            shipping: { name: $('#n').value, address: $('#a').value, city: $('#c').value, postal: $('#z').value },
          },
        });
        Cart.clear();
        location.href = `/orders.html?placed=${orderId}`;
      } catch (err) {
        showMsg($('#err'), err.message);
        btn.disabled = false;
      }
    };
  };
  draw();
};

/* ---- sign in / register ---- */
pages.login = () => {
  if (state.user) { location.href = '/'; return; }
  const next = new URLSearchParams(location.search).get('next');
  const dest = next && next.startsWith('/') && !next.startsWith('//') ? next : '/';
  app.innerHTML = `
    <h1>Your account</h1>
    <div class="auth">
      <section class="panel">
        <h2>Sign in</h2>
        <div id="lerr" class="msg err" hidden></div>
        <form id="login" class="form-grid">
          <div><label for="le">Email</label><input id="le" type="email" required autocomplete="email"></div>
          <div><label for="lp">Password</label><input id="lp" type="password" required autocomplete="current-password"></div>
          <button class="btn" type="submit">Sign in</button>
        </form>
      </section>
      <section class="panel">
        <h2>Create an account</h2>
        <div id="rerr" class="msg err" hidden></div>
        <form id="register" class="form-grid">
          <div><label for="rn">Name</label><input id="rn" required autocomplete="name"></div>
          <div><label for="re">Email</label><input id="re" type="email" required autocomplete="email"></div>
          <div><label for="rp">Password (8+ characters)</label><input id="rp" type="password" required minlength="8" autocomplete="new-password"></div>
          <button class="btn alt" type="submit">Create account</button>
        </form>
      </section>
    </div>`;
  $('#login').onsubmit = async e => {
    e.preventDefault();
    try { await api('/api/login', { method: 'POST', body: { email: $('#le').value, password: $('#lp').value } }); location.href = dest; }
    catch (err) { showMsg($('#lerr'), err.message); }
  };
  $('#register').onsubmit = async e => {
    e.preventDefault();
    try { await api('/api/register', { method: 'POST', body: { name: $('#rn').value, email: $('#re').value, password: $('#rp').value } }); location.href = dest; }
    catch (err) { showMsg($('#rerr'), err.message); }
  };
};

/* ---- order history ---- */
pages.orders = async () => {
  if (!state.user) { location.href = '/login.html?next=/orders.html'; return; }
  const placed = new URLSearchParams(location.search).get('placed');
  const orders = await api('/api/orders');
  app.innerHTML = `
    <h1>Your orders</h1>
    ${placed ? `<div class="msg ok">Order #${esc(placed)} is placed. Thanks for your order.</div>` : ''}
    ${orders.length ? orders.map(o => `
      <article class="panel order">
        <header>
          <h3>Order #${o.id}</h3>
          <span><span class="status">${esc(o.status)}</span> &nbsp; ${esc(new Date(o.created_at.replace(' ', 'T') + 'Z').toLocaleDateString())}</span>
        </header>
        <ul>${o.items.map(i => `<li>${i.quantity} &times; ${esc(i.product_name)} (${money(i.unit_price_cents)})</li>`).join('')}</ul>
        <p style="margin:.6rem 0 0"><strong>Total ${money(o.total_cents)}</strong> &middot; ships to ${esc(o.ship_name)}, ${esc(o.ship_city)}</p>
      </article>`).join('')
      : '<div class="panel empty">You haven\'t placed any orders yet. <a href="/">Browse products</a></div>'}`;
};

/* ---- boot ---- */
(async () => {
  try { state.user = await api('/api/me'); } catch { state.user = null; }
  renderHeader();
  const page = document.body.dataset.page;
  try { await pages[page](); }
  catch (e) { app.innerHTML = `<p class="msg err">${esc(e.message)}</p>`; }
})();
